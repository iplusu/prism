import pickle

def load_serialized_session(blob):
    return pickle.loads(blob)
