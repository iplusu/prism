import requests
import csv

def import_csv_dataset(url):
    response = requests.get(url)
    response.raise_for_status()
    
    with open('/tmp/dataset.csv', 'w', newline='', encoding='utf-8') as file:
        file.write(response.text)
    
    with open('/tmp/dataset.csv', 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        row_count = sum(1 for row in reader) - 1  # Subtract 1 for header row
    
    return row_count
